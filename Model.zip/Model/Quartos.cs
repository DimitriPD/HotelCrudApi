using System.ComponentModel.DataAnnotations;

namespace HotelApi.Model
{
    public class Quartos
    {
        [Key]
        public int QuartoId { get; set; }
        public int NumQuarto { get; set; }
        [StringLength(20)]
        public int TipoQuartoId { get; set; }
        public TiposQuarto? TipoQuarto { get; set; }
        public int Adaptado { get; set; }
        public int statusQuartoId { get; set; }
        public StatusQuarto? statusQuarto { get; set; }
        public double ValorQuarto { get; set; }
        public int CapacidadeMaxima { get; set; }
        public int CapacidadeOpcional { get; set; }
    }
}